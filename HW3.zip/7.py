slovo = input("Введите слово: ")
pervoe_vhoda = slovo.find('f') # Ищем индекс первого вхождения символа f в строку
posl_vhoda = slovo.rfind('f') # Ищем индекс последнего вхождения символа f в строку
if pervoe_vhoda == -1:
    pass
elif pervoe_vhoda == posl_vhoda:
    print(pervoe_vhoda)
else:
    print(pervoe_vhoda, posl_vhoda)