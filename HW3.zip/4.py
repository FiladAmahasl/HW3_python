kashi = ['Манная', 'Гречневая', 'Пшённая', 'Овсяная', 'Рисовая']
n = int(input('Кол-во дней? '))
for i in range(n):
    kasha_dnya = kashi[i % len(kashi)]
    print(f'{kasha_dnya}')