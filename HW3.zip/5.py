numbers = input("Введите цисла: ").split()
para = 0
for i in range(len(numbers)):
    for u in range(i+1, len(numbers)): #  Цикл проходится по индексам списка numbers начиная с индекса i+1, чтобы избежать повторной проверки уже проверенных пар
        if numbers[i] == numbers[u]:
            para += 1
print(para)